import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- MOCK CONTEXT STATE ---
  let appCodes = [
    { code: "abc0", namespaces: ["abc0-project-dev", "abc0-project-qa", "abc0-project-uat", "abc0-ml-rnd"] },
    { code: "zyx0", namespaces: ["zyx0-project-dev", "zyx0-project-qa", "zyx0-ml-rnd"] }
  ];

  // --- MOCK STATS STATE ---
  let namespaceStats: Record<string, any> = {
    "abc0-project-dev": { cpuUsed: 4, cpuLimit: 16, memUsed: 12, memLimit: 64, gpuUsed: 0, gpuLimit: 0 },
    "abc0-project-qa": { cpuUsed: 2, cpuLimit: 16, memUsed: 8, memLimit: 64, gpuUsed: 0, gpuLimit: 0 },
    "abc0-project-uat": { cpuUsed: 0, cpuLimit: 16, memUsed: 0, memLimit: 64, gpuUsed: 0, gpuLimit: 0 },
    "abc0-ml-rnd": { cpuUsed: 16, cpuLimit: 32, memUsed: 64, memLimit: 128, gpuUsed: 2, gpuLimit: 4 },
    "zyx0-project-dev": { cpuUsed: 2, cpuLimit: 8, memUsed: 4, memLimit: 32, gpuUsed: 0, gpuLimit: 0 },
    "zyx0-project-qa": { cpuUsed: 0, cpuLimit: 8, memUsed: 0, memLimit: 32, gpuUsed: 0, gpuLimit: 0 },
    "zyx0-ml-rnd": { cpuUsed: 8, cpuLimit: 16, memUsed: 32, memLimit: 64, gpuUsed: 1, gpuLimit: 2 },
  };

  // --- MOCK OPENSHIFT AI STATE ---
  let aiDeployments = [
    { 
      id: "dep-101", 
      name: "fraud-detection-model", 
      runtime: "Triton", 
      storageType: "S3", 
      storagePath: "s3://aifarm-models/fraud-v1/", 
      vaultFolder: "secret/data/aifarm/abc0/fraud-model",
      namespace: "abc0-ml-rnd", 
      status: "Running", 
      replicas: 2, 
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      logs: "I0317 10:00:00.000000 1 server.cc:250] Triton Inference Server starting...\nI0317 10:00:01.000000 1 model_repository_manager.cc:1050] Loading model 'fraud-detection-model'\nI0317 10:00:05.000000 1 server.cc:300] Ready to serve requests."
    },
    { 
      id: "dep-102", 
      name: "llm-assistant", 
      runtime: "vLLM", 
      storageType: "PVC", 
      storagePath: "pvc-model-weights/llama3", 
      vaultFolder: "",
      namespace: "abc0-ml-rnd", 
      status: "Running", 
      replicas: 1, 
      createdAt: new Date(Date.now() - 40000000).toISOString(),
      logs: "INFO 03-17 11:20:00 vllm.engine.arg_utils: Initializing vLLM engine...\nINFO 03-17 11:20:15 vllm.worker.worker: Loading model weights from /mnt/pvc-model-weights/llama3\nINFO 03-17 11:21:00 vllm.engine.metrics: Server started on port 8000"
    },
  ];

  // --- MOCK NORMAL WORKLOADS STATE ---
  let workloads = [
    { 
      id: "wl-001", name: "frontend-app", type: "Deployment", namespace: "abc0-project-dev", status: "Running", replicas: 3, image: "docker-abc0-dev/frontend:v1.2", 
      configMaps: [
        { name: "frontend-config", data: { "nginx.conf": "server {\n  listen 8080;\n  location / {\n    root /usr/share/nginx/html;\n    index index.html;\n  }\n}", "app.json": "{\n  \"apiUrl\": \"https://api.abc0.dev.internal\",\n  \"featureFlags\": {\n    \"newDashboard\": true\n  }\n}" } },
        { name: "ui-theme", data: { "theme.css": ":root {\n  --primary-color: #10b981;\n  --bg-color: #f8fafc;\n}" } }
      ], 
      secrets: [
        { name: "frontend-tls", data: { "tls.crt": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURaVENDQWs... (truncated)", "tls.key": "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUV2Z0lCQ... (truncated)" } }
      ], 
      routes: ["frontend-route"], 
      logs: "Starting frontend server...\nListening on port 8080...\n[INFO] Request received /api/health\n[INFO] 200 OK",
      gating: {
        githubRepo: "company-org/frontend-app",
        workflowRunUrl: "https://github.com/company-org/frontend-app/actions/runs/84729104",
        aquaScan: { status: "Passed", critical: 0, high: 2 },
        snykScan: { status: "Passed", critical: 0, high: 1 },
        sonarQube: { status: "Passed", coverage: 87.4, qualityGate: "Passed" }
      }
    },
    { 
      id: "wl-002", name: "backend-api", type: "Deployment", namespace: "abc0-project-dev", status: "Running", replicas: 5, image: "dockerhub.io/someuser/backend:latest", 
      configMaps: [
        { name: "backend-config", data: { "application.yml": "server:\n  port: 8080\nspring:\n  datasource:\n    url: jdbc:postgresql://db-service:5432/appdb\n  redis:\n    host: redis-cache\n    port: 6379" } }
      ], 
      secrets: [
        { name: "db-credentials", data: { "username": "YWRtaW4=", "password": "c3VwZXJfc2VjcmV0X3Bhc3N3b3JkXzEyMw==" } },
        { name: "api-keys", data: { "STRIPE_KEY": "c2tfcmVzdF90ZXN0XzEyMzQ1Njc4OTA=", "SENDGRID_KEY": "U0dfMTIzNDU2Nzg5MA==" } }
      ], 
      routes: ["api-route"], 
      logs: "Connecting to database...\nConnected successfully.\n[WARN] High memory usage detected.\n[INFO] Processing background jobs...",
      gating: {
        githubRepo: "company-org/backend-api",
        workflowRunUrl: "https://github.com/company-org/backend-api/actions/runs/84729105",
        aquaScan: { status: "Warning", critical: 1, high: 4 },
        snykScan: { status: "Passed", critical: 0, high: 2 },
        sonarQube: { status: "Warning", coverage: 72.1, qualityGate: "Warning" }
      }
    },
    { 
      id: "wl-003", name: "redis-cache", type: "StatefulSet", namespace: "abc0-project-dev", status: "Running", replicas: 1, image: "docker-abc0-dev/redis:6.2", 
      configMaps: [
        { name: "redis-config", data: { "redis.conf": "bind 0.0.0.0\nport 6379\nmaxmemory 256mb\nmaxmemory-policy allkeys-lru\nappendonly yes" } }
      ], 
      secrets: [], 
      routes: [], 
      logs: "1:C 17 Mar 2026 10:00:00.000 # oO0OoO0OoO0Oo Redis is starting oO0OoO0OoO0Oo\n1:M 17 Mar 2026 10:00:00.001 * Ready to accept connections",
      gating: {
        githubRepo: "company-org/redis-custom",
        workflowRunUrl: "https://github.com/company-org/redis-custom/actions/runs/84729106",
        aquaScan: { status: "Passed", critical: 0, high: 0 },
        snykScan: { status: "Passed", critical: 0, high: 0 },
        sonarQube: { status: "Passed", coverage: 95.0, qualityGate: "Passed" }
      }
    },
    { 
      id: "wl-004", name: "data-processor", type: "Deployment", namespace: "zyx0-project-dev", status: "Running", replicas: 2, image: "docker-zyx0-dev/processor:v2", 
      configMaps: [], 
      secrets: [
        { name: "aws-credentials", data: { "AWS_ACCESS_KEY_ID": "QUtJQVhYWFhYWFhYWFhYWFhYWFg=", "AWS_SECRET_ACCESS_KEY": "eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4" } }
      ], 
      routes: [], 
      logs: "Processing batch 1042...\nBatch 1042 complete.\nProcessing batch 1043...",
      gating: {
        githubRepo: "company-org/data-processor",
        workflowRunUrl: "https://github.com/company-org/data-processor/actions/runs/84729107",
        aquaScan: { status: "Failed", critical: 3, high: 12 },
        snykScan: { status: "Failed", critical: 2, high: 8 },
        sonarQube: { status: "Failed", coverage: 45.2, qualityGate: "Failed" }
      }
    },
  ];

  // --- MOCK REQUESTS STATE ---
  let requests = [
    { id: "req-002", type: "quota", status: "approved", details: { appCode: "abc0", namespace: "abc0-ml-rnd", cpu: 32, memory: 128, gpu: 4 }, requestedBy: "user@company.com", createdAt: new Date(Date.now() - 86400000).toISOString() }
  ];

  // --- API ROUTES : CONTEXT & STATS ---
  app.get("/api/context", (req, res) => res.json(appCodes));
  app.get("/api/stats", (req, res) => res.json(namespaceStats));

  // --- API ROUTES : AI DEPLOYMENTS ---
  app.get("/api/ai-deployments", (req, res) => res.json(aiDeployments));

  app.post("/api/ai-deployments", (req, res) => {
    const { name, runtime, storageType, storagePath, vaultFolder, awsKeyId, awsSecretKey, namespace, replicas } = req.body;
    const newDep = { 
      id: `dep-${Math.floor(Math.random() * 10000)}`, 
      name, runtime, storageType, storagePath, vaultFolder, namespace, 
      status: "Provisioning", replicas: replicas || 1, 
      createdAt: new Date().toISOString(),
      logs: "Pod initializing...\nPulling image...\nMounting volumes..."
    };
    aiDeployments.push(newDep);
    setTimeout(() => { const d = aiDeployments.find(x => x.id === newDep.id); if (d) d.status = "Running"; }, 4000);
    res.json(newDep);
  });

  app.delete("/api/ai-deployments/:id", (req, res) => {
    const { id } = req.params;
    const dep = aiDeployments.find(d => d.id === id);
    if (!dep) return res.status(404).json({ error: "Not found" });
    dep.status = "Terminating";
    setTimeout(() => { aiDeployments = aiDeployments.filter(d => d.id !== id); }, 3000);
    res.json({ success: true });
  });

  // --- API ROUTES : NORMAL WORKLOADS ---
  app.get("/api/workloads", (req, res) => res.json(workloads));

  app.delete("/api/workloads/:id", (req, res) => {
    const { id } = req.params;
    const wl = workloads.find(w => w.id === id);
    if (!wl) return res.status(404).json({ error: "Not found" });
    wl.status = "Terminating";
    setTimeout(() => { workloads = workloads.filter(w => w.id !== id); }, 3000);
    res.json({ success: true });
  });

  // --- API ROUTES : REQUESTS ---
  app.get("/api/requests", (req, res) => res.json(requests));

  app.post("/api/requests", (req, res) => {
    const { type, details } = req.body;
    const newReq = { id: `req-${Math.floor(Math.random() * 10000)}`, type, status: "pending", details, requestedBy: "user@company.com", createdAt: new Date().toISOString() };
    requests.push(newReq);
    res.json(newReq);
  });

  app.put("/api/requests/:id/approve", (req, res) => {
    const reqItem = requests.find(r => r.id === req.params.id);
    if (!reqItem) return res.status(404).json({ error: "Not found" });
    reqItem.status = "approved";
    res.json(reqItem);
  });

  app.put("/api/requests/:id/reject", (req, res) => {
    const reqItem = requests.find(r => r.id === req.params.id);
    if (!reqItem) return res.status(404).json({ error: "Not found" });
    reqItem.status = "rejected";
    res.json(reqItem);
  });

  // --- MOCK USERS & ONBOARDING STATE ---
  let users = [
    { username: "admin", role: "admin", onboarded: true, appCode: "abc0" },
    { username: "user1", role: "user", onboarded: false },
    { username: "user2", role: "user", onboarded: true, appCode: "zyx0" }
  ];

  let onboardingRequests = [
    { id: "onb-1", username: "user1", appCode: "newapp", projectName: "New Project", usage: "Testing LLMs", status: "pending", createdAt: new Date().toISOString() }
  ];

  app.post("/api/login", (req, res) => {
    const { username } = req.body;
    let user = users.find(u => u.username === username);
    if (!user) {
      user = { username, role: "user", onboarded: false };
      users.push(user);
    }
    const hasPendingRequest = onboardingRequests.some(r => r.username === username && r.status === "pending");
    res.json({ ...user, hasPendingRequest });
  });

  app.post("/api/onboard", (req, res) => {
    const { username, appCode, projectName, usage } = req.body;
    const newReq = { id: `onb-${Date.now()}`, username, appCode, projectName, usage, status: "pending", createdAt: new Date().toISOString() };
    onboardingRequests.push(newReq);
    res.json(newReq);
  });

  app.get("/api/deployments", (req, res) => res.json(aiDeployments));
  app.get("/api/users", (req, res) => res.json(users));

  app.get("/api/onboarding-requests", (req, res) => {
    res.json(onboardingRequests);
  });

  app.post("/api/onboarding-requests/:id/approve", (req, res) => {
    const reqItem = onboardingRequests.find(r => r.id === req.params.id);
    if (!reqItem) return res.status(404).json({ error: "Not found" });
    reqItem.status = "approved";
    const user = users.find(u => u.username === reqItem.username);
    if (user) {
      user.onboarded = true;
      user.appCode = reqItem.appCode;
      if (!appCodes.find(c => c.code === reqItem.appCode)) {
        appCodes.push({ code: reqItem.appCode, namespaces: [`${reqItem.appCode}-project-dev`] });
      }
    }
    res.json(reqItem);
  });

  app.post("/api/onboarding-requests/:id/reject", (req, res) => {
    const reqItem = onboardingRequests.find(r => r.id === req.params.id);
    if (!reqItem) return res.status(404).json({ error: "Not found" });
    reqItem.status = "rejected";
    res.json(reqItem);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  app.listen(PORT, "0.0.0.0", () => console.log(`Server running on http://localhost:${PORT}`));
}

startServer();
