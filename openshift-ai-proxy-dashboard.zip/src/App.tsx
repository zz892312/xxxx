import React, { useState, useEffect, useMemo, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Server, Activity, Trash2, RefreshCw, Plus, X,
  Cpu, Database, ClipboardList, CheckCircle, XCircle, ShieldCheck, User,
  ChevronDown, Folder, AlertTriangle, Terminal, HardDrive, Layers, LayoutDashboard,
  Eye, EyeOff, TerminalSquare, FileText, Lock, Sparkles, Shield, ExternalLink, Copy, Check,
  MessageSquare, Send
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type AppCodeContext = { code: string; namespaces: string[]; };
type NamespaceStats = { cpuUsed: number; cpuLimit: number; memUsed: number; memLimit: number; gpuUsed: number; gpuLimit: number; };
type AIDeployment = { id: string; name: string; runtime: string; storageType: string; storagePath: string; vaultFolder?: string; namespace: string; status: string; replicas: number; createdAt: string; logs: string; };
type ConfigMapOrSecret = { name: string; data: Record<string, string> };
type GatingInfo = { githubRepo: string; workflowRunUrl: string; aquaScan: { status: string; critical: number; high: number; }; snykScan: { status: string; critical: number; high: number; }; sonarQube: { status: string; coverage: number; qualityGate: string; }; };
type Workload = { id: string; name: string; type: string; namespace: string; status: string; replicas: number; image: string; configMaps: ConfigMapOrSecret[]; secrets: ConfigMapOrSecret[]; routes: string[]; logs: string; gating?: GatingInfo; };
type RequestItem = { id: string; type: 'quota'; status: 'pending' | 'approved' | 'rejected'; details: any; requestedBy: string; createdAt: string; };
type User = { username: string; role: 'admin' | 'user'; onboarded: boolean; appCode?: string; hasPendingRequest?: boolean; };
type OnboardingRequest = { id: string; username: string; appCode: string; projectName: string; usage: string; status: 'pending' | 'approved' | 'rejected'; createdAt: string; };

function Login({ onLogin }: { onLogin: (user: User) => void }) {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim() })
      });
      if (!res.ok) throw new Error('Login failed');
      const user = await res.json();
      onLogin(user);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 selection:bg-emerald-500/30">
      <div className="w-full max-w-md bg-[#111111] border border-white/10 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-indigo-500/10 to-transparent pointer-events-none" />
        <div className="relative z-10">
          <div className="flex justify-center mb-8">
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
              <Server className="w-8 h-8 text-indigo-400" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-white text-center mb-2">Welcome to AIFarm</h1>
          <p className="text-neutral-400 text-center mb-8">Sign in to manage your AI workloads</p>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Username</label>
              <input 
                type="text" 
                required 
                value={username} 
                onChange={e => setUsername(e.target.value)} 
                className="w-full px-4 py-3 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white" 
                placeholder="Enter your username"
              />
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl font-medium transition-colors disabled:opacity-50"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

function Onboarding({ user, onComplete, onLogout }: { user: User, onComplete: (user: User) => void, onLogout: () => void }) {
  const [appCode, setAppCode] = useState('');
  const [projectName, setProjectName] = useState('');
  const [usage, setUsage] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(user.hasPendingRequest || false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch('/api/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user.username, appCode, projectName, usage })
      });
      setSubmitted(true);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#111111] border border-white/10 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-4">Request Submitted</h2>
          <p className="text-neutral-400 mb-6">Your onboarding request has been submitted to the administrators. You will be able to access the platform once it is approved.</p>
          <div className="flex gap-4 justify-center">
            <button onClick={async () => {
              try {
                const res = await fetch('/api/login', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ username: user.username })
                });
                if (res.ok) {
                  const updatedUser = await res.json();
                  if (updatedUser.onboarded) {
                    onComplete(updatedUser);
                  } else {
                    alert('Your request is still pending approval.');
                  }
                }
              } catch (e) {
                console.error(e);
              }
            }} className="px-6 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium transition-colors">
              Check Status
            </button>
            <button onClick={onLogout} className="px-6 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl font-medium transition-colors">
              Logout
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 selection:bg-emerald-500/30">
      <div className="w-full max-w-lg bg-[#111111] border border-white/10 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
        <h1 className="text-2xl font-bold text-white mb-2">Welcome, {user.username}</h1>
        <p className="text-neutral-400 mb-8">You didn't onboard please fill in this form to request access.</p>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">App Code</label>
            <input type="text" required value={appCode} onChange={e => setAppCode(e.target.value)} className="w-full px-4 py-3 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white" placeholder="e.g. abc0" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Project Name</label>
            <input type="text" required value={projectName} onChange={e => setProjectName(e.target.value)} className="w-full px-4 py-3 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white" placeholder="Project Name" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Usage Description</label>
            <textarea required value={usage} onChange={e => setUsage(e.target.value)} className="w-full px-4 py-3 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white h-32 resize-none" placeholder="Describe how you plan to use the platform..." />
          </div>
          <div className="flex gap-4">
            <button type="submit" disabled={loading} className="flex-1 py-3 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl font-medium transition-colors disabled:opacity-50">
              {loading ? 'Submitting...' : 'Submit Request'}
            </button>
            <button type="button" onClick={onLogout} className="px-6 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors">
              Logout
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'inference-services' | 'workloads' | 'requests'>('overview');
  const [user, setUser] = useState<User | null>(null);
  const [onboardingRequests, setOnboardingRequests] = useState<OnboardingRequest[]>([]);
  
  const [appCodes, setAppCodes] = useState<AppCodeContext[]>([]);
  const [selectedAppCode, setSelectedAppCode] = useState<string>('');
  
  const [stats, setStats] = useState<Record<string, NamespaceStats>>({});
  const [aiDeployments, setAiDeployments] = useState<AIDeployment[]>([]);
  const [workloads, setWorkloads] = useState<Workload[]>([]);
  const [requests, setRequests] = useState<RequestItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Modals
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [workloadToDelete, setWorkloadToDelete] = useState<Workload | null>(null);
  const [activeLogs, setActiveLogs] = useState<{name: string, logs: string} | null>(null);
  const [activeExec, setActiveExec] = useState<{name: string} | null>(null);
  const [activeResourceView, setActiveResourceView] = useState<{workloadName: string, type: 'ConfigMaps' | 'Secrets', items: ConfigMapOrSecret[]} | null>(null);
  const [activeGatingView, setActiveGatingView] = useState<Workload | null>(null);
  
  // Deploy Form
  const [deploymentName, setDeploymentName] = useState('');
  const [deployNamespace, setDeployNamespace] = useState('');
  const [runtime, setRuntime] = useState('Triton');
  const [storageType, setStorageType] = useState('S3');
  const [storagePath, setStoragePath] = useState('');
  const [vaultFolder, setVaultFolder] = useState('');
  const [awsKeyId, setAwsKeyId] = useState('');
  const [awsSecretKey, setAwsSecretKey] = useState('');
  const [replicas, setReplicas] = useState(1);

  // Request Form
  const [reqEnvTarget, setReqEnvTarget] = useState('dev');
  const [reqCpu, setReqCpu] = useState(4);
  const [reqMem, setReqMem] = useState(16);
  const [reqGpu, setReqGpu] = useState(0);

  const fetchData = async () => {
    if (!user || !user.onboarded) return;
    setLoading(true);
    try {
      const promises = [
        fetch('/api/context'), fetch('/api/stats'), fetch('/api/ai-deployments'), fetch('/api/workloads'), fetch('/api/requests')
      ];
      if (user.role === 'admin') {
        promises.push(fetch('/api/onboarding-requests'));
      }
      const results = await Promise.all(promises);
      const ctxData = await results[0].json();
      setAppCodes(ctxData);
      
      // If user is not admin, only show their appCode
      if (user.role !== 'admin' && user.appCode) {
        setSelectedAppCode(user.appCode);
      } else if (!selectedAppCode && ctxData.length > 0) {
        setSelectedAppCode(ctxData[0].code);
      }
      
      setStats(await results[1].json());
      setAiDeployments(await results[2].json());
      setWorkloads(await results[3].json());
      setRequests(await results[4].json());
      
      if (user.role === 'admin') {
        setOnboardingRequests(await results[5].json());
      }
    } catch (error) {
      console.error('Failed to fetch data', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && user.onboarded) {
      fetchData();
      const interval = setInterval(fetchData, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedAppCode, user]);

  const activeContext = useMemo(() => {
    if (selectedAppCode === 'all') {
      return { code: 'all', namespaces: appCodes.flatMap(c => c.namespaces) };
    }
    return appCodes.find(c => c.code === selectedAppCode);
  }, [appCodes, selectedAppCode]);
  
  const filteredWorkloads = useMemo(() => {
    if (!activeContext) return [];
    return workloads.filter(w => activeContext.namespaces.includes(w.namespace));
  }, [workloads, activeContext]);

  const filteredAiDeployments = useMemo(() => {
    if (!activeContext) return [];
    return aiDeployments.filter(d => activeContext.namespaces.includes(d.namespace));
  }, [aiDeployments, activeContext]);

  const workloadsByNamespace = useMemo<Record<string, Workload[]>>(() => {
    const grouped: Record<string, Workload[]> = {};
    activeContext?.namespaces.forEach(ns => grouped[ns] = []);
    filteredWorkloads.forEach(w => {
      if (grouped[w.namespace]) grouped[w.namespace].push(w);
      else grouped[w.namespace] = [w];
    });
    return grouped;
  }, [filteredWorkloads, activeContext]);

  const aggregatedStats = useMemo(() => {
    let cpuUsed = 0, cpuLimit = 0, memUsed = 0, memLimit = 0, gpuUsed = 0, gpuLimit = 0;
    let totalWorkloads = filteredWorkloads.length;
    let inferenceServices = filteredAiDeployments.length;
    let llms = filteredAiDeployments.filter(d => d.runtime === 'vLLM' || d.runtime === 'Ollama').length;

    if (activeContext) {
      activeContext.namespaces.forEach(ns => {
        const s = stats[ns];
        if (s) {
          cpuUsed += s.cpuUsed; cpuLimit += s.cpuLimit;
          memUsed += s.memUsed; memLimit += s.memLimit;
          gpuUsed += s.gpuUsed; gpuLimit += s.gpuLimit;
        }
      });
    }
    return { cpuUsed, cpuLimit, memUsed, memLimit, gpuUsed, gpuLimit, totalWorkloads, inferenceServices, llms };
  }, [activeContext, stats, filteredWorkloads, filteredAiDeployments]);

  const isImageValid = (image: string, appCode: string) => {
    const code = appCode.toLowerCase();
    return image.startsWith(`docker-${code}-dev`) || 
           image.startsWith(`docker-${code}-qat`) || 
           image.startsWith(`docker-${code}-uat`) || 
           image.startsWith(`docker-${code}-prod`);
  };

  const handleDeploy = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload: any = { name: deploymentName, runtime, storageType, storagePath, namespace: deployNamespace, replicas, vaultFolder };
      if (storageType === 'S3') {
        payload.awsKeyId = awsKeyId;
        payload.awsSecretKey = awsSecretKey;
      }

      await fetch('/api/ai-deployments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      setIsDeployModalOpen(false);
      setDeploymentName('');
      setStoragePath('');
      setVaultFolder('');
      setAwsKeyId('');
      setAwsSecretKey('');
      setReplicas(1);
      fetchData();
      setActiveTab('inference-services');
    } catch (error) {
      console.error('Failed to deploy', error);
    }
  };

  const handleDeleteAIDeployment = async (id: string) => {
    try { await fetch(`/api/ai-deployments/${id}`, { method: 'DELETE' }); fetchData(); } 
    catch (error) { console.error('Failed to delete', error); }
  };

  const confirmDeleteWorkload = async () => {
    if (!workloadToDelete) return;
    try { 
      await fetch(`/api/workloads/${workloadToDelete.id}`, { method: 'DELETE' }); 
      setWorkloadToDelete(null);
      fetchData(); 
    } 
    catch (error) { console.error('Failed to delete', error); }
  };

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let details: any = { 
        appCode: selectedAppCode,
        namespace: `${selectedAppCode.toLowerCase()}-${reqEnvTarget === 'ml-rnd' ? 'ml-rnd' : `project-${reqEnvTarget}`}`,
        cpu: reqCpu, memory: reqMem, gpu: reqGpu 
      };

      await fetch('/api/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'quota', details })
      });
      setIsRequestModalOpen(false);
      fetchData();
      setActiveTab('requests');
    } catch (error) {
      console.error('Failed to create request', error);
    }
  };

  const handleAdminAction = async (id: string, action: 'approve' | 'reject') => {
    try {
      await fetch(`/api/requests/${id}/${action}`, { method: 'PUT' });
      fetchData();
    } catch (error) {
      console.error(`Failed to ${action} request`, error);
    }
  };

  const openDeployModal = () => {
    const mlNamespace = activeContext?.namespaces.find(n => n.includes('ml-rnd')) || activeContext?.namespaces[0] || '';
    setDeployNamespace(mlNamespace);
    setIsDeployModalOpen(true);
  };

  const handleApproveOnboarding = async (id: string) => {
    try {
      await fetch(`/api/onboarding-requests/${id}/approve`, { method: 'POST' });
      fetchData();
    } catch (e) { console.error(e); }
  };

  const handleRejectOnboarding = async (id: string) => {
    try {
      await fetch(`/api/onboarding-requests/${id}/reject`, { method: 'POST' });
      fetchData();
    } catch (e) { console.error(e); }
  };

  if (!user) {
    return <Login onLogin={setUser} />;
  }

  if (!user.onboarded) {
    return <Onboarding user={user} onComplete={setUser} onLogout={() => setUser(null)} />;
  }

  const isAdmin = user.role === 'admin';
  const themeClass = isAdmin ? 'theme-admin' : '';

  return (
    <div className={`min-h-screen bg-[#0a0a0a] text-neutral-200 flex font-sans selection:bg-emerald-500/30 ${themeClass}`}>
      {/* Sidebar */}
      <aside className="w-64 bg-[#111111] border-r border-white/5 flex flex-col relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-emerald-500/10 to-transparent pointer-events-none" />
        
        <div className="p-6 flex items-center gap-3 text-white font-semibold text-lg border-b border-white/5 relative z-10">
          <div className="relative">
            <div className="absolute inset-0 bg-emerald-500 blur-md opacity-40 rounded-full" />
            <Server className="w-6 h-6 text-emerald-400 relative z-10" />
          </div>
          <span className="tracking-tight">AIFARM Portal</span>
        </div>
        
        <div className="px-4 py-5 border-b border-white/5 bg-white/[0.02]">
          <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-semibold mb-2 block">Active AppCode</label>
          <div className="relative group">
            <select 
              value={selectedAppCode}
              onChange={e => setSelectedAppCode(e.target.value)}
              className="w-full appearance-none bg-neutral-900/50 border border-white/10 text-white rounded-lg pl-3 pr-8 py-2 text-sm focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all cursor-pointer hover:bg-neutral-800/50"
            >
              {isAdmin && <option value="all">All Namespaces</option>}
              {appCodes.map(ac => <option key={ac.code} value={ac.code}>{ac.code}</option>)}
            </select>
            <ChevronDown className="w-4 h-4 text-neutral-400 absolute right-3 top-2.5 pointer-events-none group-hover:text-white transition-colors" />
          </div>
        </div>
        
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto relative z-10">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${activeTab === 'overview' ? 'bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(16,185,129,0.1)]' : 'text-neutral-400 hover:bg-white/5 hover:text-neutral-200'}`}
          >
            <LayoutDashboard className="w-4 h-4" /> <span className="text-sm font-medium">Dashboard</span>
          </button>

          <div className="px-3 text-[10px] font-semibold text-neutral-600 uppercase tracking-widest mb-2 mt-6">AI Features</div>
          <button 
            onClick={() => setActiveTab('inference-services')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${activeTab === 'inference-services' ? 'bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(16,185,129,0.1)]' : 'text-neutral-400 hover:bg-white/5 hover:text-neutral-200'}`}
          >
            <Activity className="w-4 h-4" /> <span className="text-sm font-medium">Inference Services</span>
          </button>

          <div className="px-3 text-[10px] font-semibold text-neutral-600 uppercase tracking-widest mb-2 mt-6">Core Infrastructure</div>
          <button 
            onClick={() => setActiveTab('workloads')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${activeTab === 'workloads' ? 'bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(16,185,129,0.1)]' : 'text-neutral-400 hover:bg-white/5 hover:text-neutral-200'}`}
          >
            <Database className="w-4 h-4" /> <span className="text-sm font-medium">Workloads</span>
          </button>
          <button 
            onClick={() => setActiveTab('requests')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${activeTab === 'requests' ? 'bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(16,185,129,0.1)]' : 'text-neutral-400 hover:bg-white/5 hover:text-neutral-200'}`}
          >
            <ClipboardList className="w-4 h-4" /> <span className="text-sm font-medium">Requests</span>
          </button>
        </nav>

        <div className="p-4 border-t border-white/5 bg-[#0a0a0a]">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-semibold">User</span>
            <button 
              onClick={() => setUser(null)}
              className="text-xs bg-neutral-900 border border-white/10 hover:border-white/20 text-neutral-300 px-2.5 py-1.5 rounded-md transition-all flex items-center gap-1.5"
            >
              {user?.role === 'user' ? <User className="w-3 h-3" /> : <ShieldCheck className="w-3 h-3 text-emerald-400" />}
              {user?.username} (Logout)
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/5 blur-[120px] rounded-full pointer-events-none" />
        
        <header className="bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-white/5 px-8 py-6 flex justify-between items-center sticky top-0 z-20">
          <div>
            <h1 className="text-2xl font-semibold text-white tracking-tight flex items-center gap-2">
              {activeTab === 'overview' && 'Dashboard Overview'}
              {activeTab === 'inference-services' && 'Inference Services'}
              {activeTab === 'workloads' && 'Standard Workloads'}
              {activeTab === 'requests' && 'Resource & Quota Requests'}
            </h1>
            <p className="text-sm text-neutral-500 mt-1 flex items-center gap-2">
              Context: <span className="font-mono text-xs bg-white/5 px-2 py-0.5 rounded text-neutral-300">{selectedAppCode}</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={fetchData} className="p-2.5 bg-neutral-900 border border-white/5 text-neutral-400 hover:text-white hover:border-white/20 rounded-lg transition-all" title="Refresh">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            {activeTab === 'inference-services' && (
              <button onClick={() => openDeployModal()} className="flex items-center gap-2 bg-white text-black hover:bg-neutral-200 px-4 py-2.5 rounded-lg text-sm font-medium transition-all shadow-[0_0_15px_rgba(255,255,255,0.1)]">
                <Sparkles className="w-4 h-4" /> Deploy Model
              </button>
            )}
            {activeTab === 'requests' && user?.role !== 'admin' && (
              <button onClick={() => setIsRequestModalOpen(true)} className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-400 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-all shadow-[0_0_15px_rgba(99,102,241,0.2)]">
                <Plus className="w-4 h-4" /> New Request
              </button>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-auto p-8 relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {/* OVERVIEW TAB */}
              {activeTab === 'overview' && (
                <div className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <StatCard icon={<Cpu />} title="CPU Usage" used={aggregatedStats.cpuUsed} limit={aggregatedStats.cpuLimit} unit="Cores" color="blue" />
                    <StatCard icon={<Database />} title="Memory Usage" used={aggregatedStats.memUsed} limit={aggregatedStats.memLimit} unit="Gi" color="purple" />
                    <StatCard icon={<Layers />} title="GPU Usage" used={aggregatedStats.gpuUsed} limit={aggregatedStats.gpuLimit} unit="GPUs" color="emerald" />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-[#111111] rounded-2xl border border-white/5 p-6 relative overflow-hidden group hover:border-white/10 transition-colors">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl"><Activity className="w-5 h-5" /></div>
                        <h3 className="text-sm font-medium text-neutral-400">Total Workloads</h3>
                      </div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-4xl font-semibold text-white tracking-tight">{aggregatedStats.totalWorkloads}</span>
                        <span className="text-sm text-neutral-500">Active</span>
                      </div>
                    </div>
                    <div className="bg-[#111111] rounded-2xl border border-white/5 p-6 relative overflow-hidden group hover:border-white/10 transition-colors">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl"><Sparkles className="w-5 h-5" /></div>
                        <h3 className="text-sm font-medium text-neutral-400">Inference Services</h3>
                      </div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-4xl font-semibold text-white tracking-tight">{aggregatedStats.inferenceServices}</span>
                        <span className="text-sm text-neutral-500">Active</span>
                      </div>
                    </div>
                    <div className="bg-[#111111] rounded-2xl border border-white/5 p-6 relative overflow-hidden group hover:border-white/10 transition-colors">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl"><Cpu className="w-5 h-5" /></div>
                        <h3 className="text-sm font-medium text-neutral-400">LLMs</h3>
                      </div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-4xl font-semibold text-white tracking-tight">{aggregatedStats.llms}</span>
                        <span className="text-sm text-neutral-500">Active</span>
                      </div>
                    </div>
                  </div>

                  <h2 className="text-lg font-semibold text-white mt-10 mb-6 tracking-tight">Namespace Breakdown</h2>
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {activeContext?.namespaces.map(ns => {
                      const s = stats[ns] || { cpuUsed: 0, cpuLimit: 0, memUsed: 0, memLimit: 0, gpuUsed: 0, gpuLimit: 0 };
                      const wls = workloadsByNamespace[ns]?.length || 0;
                      const aiDeps = filteredAiDeployments.filter(d => d.namespace === ns).length;
                      return (
                        <div key={ns} className="bg-[#111111] rounded-2xl border border-white/5 overflow-hidden hover:border-white/10 transition-colors">
                          <div className="px-5 py-4 border-b border-white/5 bg-white/[0.02] flex items-center gap-3">
                            <Folder className="w-4 h-4 text-neutral-500" />
                            <span className="font-mono text-sm font-medium text-neutral-300">{ns}</span>
                          </div>
                          <div className="p-5 space-y-4">
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-neutral-500">CPU</span>
                              <span className="font-mono text-neutral-300">{s.cpuUsed} / {s.cpuLimit}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-neutral-500">Memory</span>
                              <span className="font-mono text-neutral-300">{s.memUsed} / {s.memLimit} Gi</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-neutral-500">GPU</span>
                              <span className="font-mono text-neutral-300">{s.gpuUsed} / {s.gpuLimit}</span>
                            </div>
                            <div className="pt-4 border-t border-white/5 flex justify-between items-center text-sm">
                              <span className="text-neutral-500">Workloads</span>
                              <span className="font-medium text-white bg-white/10 px-2 py-0.5 rounded-md">{wls + aiDeps}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* INFERENCE SERVICES TAB */}
              {activeTab === 'inference-services' && (
                <div className="bg-[#111111] rounded-2xl border border-white/5 overflow-hidden">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-white/[0.02] border-b border-white/5 text-xs text-neutral-500 uppercase tracking-widest">
                        <th className="px-6 py-4 font-medium">Name</th>
                        <th className="px-6 py-4 font-medium">Runtime</th>
                        <th className="px-6 py-4 font-medium">Storage</th>
                        <th className="px-6 py-4 font-medium">Namespace</th>
                        <th className="px-6 py-4 font-medium">Status</th>
                        <th className="px-6 py-4 font-medium">Replicas</th>
                        <th className="px-6 py-4 font-medium text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {filteredAiDeployments.length === 0 ? (
                        <tr><td colSpan={7} className="px-6 py-16 text-center text-neutral-500">No active inference services in {selectedAppCode}.</td></tr>
                      ) : (
                        filteredAiDeployments.map(dep => (
                          <tr key={dep.id} className="hover:bg-white/[0.02] transition-colors group">
                            <td className="px-6 py-4 font-medium text-neutral-200">{dep.name}</td>
                            <td className="px-6 py-4 text-neutral-400">
                              <div className="flex items-center gap-2 text-sm"><Cpu className="w-4 h-4 text-neutral-500" />{dep.runtime}</div>
                            </td>
                            <td className="px-6 py-4 text-neutral-400">
                              <div className="flex items-center gap-1.5 text-sm font-medium text-neutral-300">
                                <HardDrive className="w-3.5 h-3.5 text-neutral-500" /> {dep.storageType}
                              </div>
                              <div className="text-xs text-neutral-500 font-mono truncate max-w-[150px] mt-1" title={dep.storagePath}>{dep.storagePath}</div>
                              {dep.vaultFolder && <div className="text-[10px] text-indigo-400 mt-1 truncate max-w-[150px]" title={dep.vaultFolder}>Vault: {dep.vaultFolder}</div>}
                            </td>
                            <td className="px-6 py-4 text-neutral-500 font-mono text-xs">{dep.namespace}</td>
                            <td className="px-6 py-4">
                              <StatusBadge status={dep.status} />
                            </td>
                            <td className="px-6 py-4 text-neutral-400 font-mono text-sm">{dep.replicas}</td>
                            <td className="px-6 py-4 text-right">
                              <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <ActionButton icon={<TerminalSquare />} onClick={() => setActiveExec({ name: dep.name })} title="Exec" color="blue" />
                                <ActionButton icon={<Terminal />} onClick={() => setActiveLogs({ name: dep.name, logs: dep.logs })} title="Logs" color="indigo" />
                                <ActionButton icon={<Trash2 />} onClick={() => handleDeleteAIDeployment(dep.id)} disabled={dep.status === 'Terminating'} title="Delete" color="red" />
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {/* WORKLOADS TAB */}
              {activeTab === 'workloads' && (
                <div className="space-y-8">
                  {(Object.entries(workloadsByNamespace) as [string, Workload[]][]).map(([namespace, wls]) => (
                    <div key={namespace} className="bg-[#111111] rounded-2xl border border-white/5 overflow-hidden">
                      <div className="px-6 py-4 border-b border-white/5 bg-white/[0.02] flex items-center gap-3">
                        <Folder className="w-5 h-5 text-neutral-500" />
                        <h2 className="text-sm font-medium text-neutral-300 font-mono">{namespace}</h2>
                        <span className="ml-auto bg-white/10 text-neutral-300 px-2.5 py-1 rounded-md text-xs font-medium">{wls.length} Workloads</span>
                      </div>
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-transparent border-b border-white/5 text-xs text-neutral-500 uppercase tracking-widest">
                            <th className="px-6 py-4 font-medium">Name & Resources</th>
                            <th className="px-6 py-4 font-medium">Type</th>
                            <th className="px-6 py-4 font-medium">Image</th>
                            <th className="px-6 py-4 font-medium">Status</th>
                            <th className="px-6 py-4 font-medium">Replicas</th>
                            <th className="px-6 py-4 font-medium text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {wls.length === 0 ? (
                            <tr><td colSpan={6} className="px-6 py-12 text-center text-neutral-500 text-sm">No workloads in this namespace.</td></tr>
                          ) : (
                            wls.map(wl => (
                              <tr key={wl.id} className="hover:bg-white/[0.02] transition-colors group">
                                <td className="px-6 py-4">
                                  <div className="font-medium text-neutral-200 text-sm">{wl.name}</div>
                                  <div className="flex gap-2 mt-2">
                                    {wl.configMaps.length > 0 && (
                                      <button onClick={() => setActiveResourceView({ workloadName: wl.name, type: 'ConfigMaps', items: wl.configMaps })} className="text-[10px] bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 px-2 py-0.5 rounded border border-blue-500/20 transition-colors cursor-pointer">
                                        CM: {wl.configMaps.length}
                                      </button>
                                    )}
                                    {wl.secrets.length > 0 && (
                                      <button onClick={() => setActiveResourceView({ workloadName: wl.name, type: 'Secrets', items: wl.secrets })} className="text-[10px] bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 px-2 py-0.5 rounded border border-purple-500/20 transition-colors cursor-pointer">
                                        Sec: {wl.secrets.length}
                                      </button>
                                    )}
                                    {wl.routes.length > 0 && (
                                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                                        Rt: {wl.routes.length}
                                      </span>
                                    )}
                                    {wl.gating && (
                                      <button onClick={() => setActiveGatingView(wl)} className="text-[10px] bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 px-2 py-0.5 rounded border border-indigo-500/20 transition-colors cursor-pointer flex items-center gap-1">
                                        <Shield className="w-3 h-3" /> CI/CD
                                      </button>
                                    )}
                                  </div>
                                </td>
                                <td className="px-6 py-4 text-neutral-500 text-sm">{wl.type}</td>
                                <td className="px-6 py-4">
                                  <div className="text-sm text-neutral-400 font-mono truncate max-w-[200px]" title={wl.image}>{wl.image}</div>
                                  {!isImageValid(wl.image, selectedAppCode) && (
                                    <div className="text-[10px] text-amber-500 flex items-center gap-1 mt-1.5 font-medium">
                                      <AlertTriangle className="w-3 h-3" /> Unregistered Registry
                                    </div>
                                  )}
                                </td>
                                <td className="px-6 py-4">
                                  <StatusBadge status={wl.status} />
                                </td>
                                <td className="px-6 py-4 text-neutral-500 font-mono text-sm">{wl.replicas}</td>
                                <td className="px-6 py-4 text-right">
                                  <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <ActionButton icon={<TerminalSquare />} onClick={() => setActiveExec({ name: wl.name })} title="Exec" color="blue" />
                                    <ActionButton icon={<Terminal />} onClick={() => setActiveLogs({ name: wl.name, logs: wl.logs })} title="Logs" color="indigo" />
                                    <ActionButton icon={<Trash2 />} onClick={() => setWorkloadToDelete(wl)} disabled={wl.status === 'Terminating'} title="Delete" color="red" />
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  ))}
                </div>
              )}

              {/* REQUESTS TAB */}
              {activeTab === 'requests' && (
                <div className="space-y-6">
                  {user?.role === 'admin' && (
                    <div className="bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 px-5 py-4 rounded-xl flex items-center gap-3">
                      <ShieldCheck className="w-5 h-5 text-indigo-400" />
                      <p className="text-sm font-medium">Admin View: You have permission to approve or reject pending resource and onboarding requests.</p>
                    </div>
                  )}
                  
                  {user?.role === 'admin' && (
                    <div className="bg-[#111111] rounded-2xl border border-white/5 overflow-hidden mb-8">
                      <div className="px-6 py-4 border-b border-white/5 bg-white/[0.02]">
                        <h3 className="text-sm font-medium text-neutral-300">Onboarding Requests</h3>
                      </div>
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-white/[0.02] border-b border-white/5 text-xs text-neutral-500 uppercase tracking-widest">
                            <th className="px-6 py-4 font-medium">User</th>
                            <th className="px-6 py-4 font-medium">App Code</th>
                            <th className="px-6 py-4 font-medium">Project Name</th>
                            <th className="px-6 py-4 font-medium">Usage</th>
                            <th className="px-6 py-4 font-medium">Status</th>
                            <th className="px-6 py-4 font-medium text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {onboardingRequests.length === 0 ? (
                            <tr><td colSpan={6} className="px-6 py-8 text-center text-neutral-500 text-sm">No onboarding requests found.</td></tr>
                          ) : (
                            onboardingRequests.map(req => (
                              <tr key={req.id} className="hover:bg-white/[0.02] transition-colors group">
                                <td className="px-6 py-4 text-white font-medium text-sm">{req.username}</td>
                                <td className="px-6 py-4 text-neutral-400 font-mono text-sm">{req.appCode}</td>
                                <td className="px-6 py-4 text-neutral-400 text-sm">{req.projectName}</td>
                                <td className="px-6 py-4 text-neutral-400 text-sm max-w-xs truncate" title={req.usage}>{req.usage}</td>
                                <td className="px-6 py-4">
                                  <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium border ${req.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : req.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                                    {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                  {req.status === 'pending' && (
                                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <button onClick={() => handleApproveOnboarding(req.id)} className="p-2 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded-lg transition-colors" title="Approve"><Check className="w-4 h-4" /></button>
                                      <button onClick={() => handleRejectOnboarding(req.id)} className="p-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors" title="Reject"><X className="w-4 h-4" /></button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <div className="bg-[#111111] rounded-2xl border border-white/5 overflow-hidden">
                    <div className="px-6 py-4 border-b border-white/5 bg-white/[0.02]">
                      <h3 className="text-sm font-medium text-neutral-300">Resource Quota Requests</h3>
                    </div>
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-white/[0.02] border-b border-white/5 text-xs text-neutral-500 uppercase tracking-widest">
                          <th className="px-6 py-4 font-medium">Type</th>
                          <th className="px-6 py-4 font-medium">Details</th>
                          <th className="px-6 py-4 font-medium">Requested By</th>
                          <th className="px-6 py-4 font-medium">Status</th>
                          <th className="px-6 py-4 font-medium text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {requests.length === 0 ? (
                          <tr><td colSpan={5} className="px-6 py-16 text-center text-neutral-500">No requests found.</td></tr>
                        ) : (
                          requests.map(req => (
                            <tr key={req.id} className="hover:bg-white/[0.02] transition-colors">
                              <td className="px-6 py-4">
                                <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium border bg-purple-500/10 text-purple-400 border-purple-500/20">
                                  Quota Adjustment
                                </span>
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm text-neutral-200 font-medium mb-2">
                                  App: <span className="font-mono text-xs">{req.details.appCode}</span>
                                  {req.details.namespace && <span className="text-neutral-500 font-normal ml-2">| NS: <span className="font-mono text-xs">{req.details.namespace}</span></span>}
                                </div>
                                <div className="flex gap-4 text-xs text-neutral-400">
                                  <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5 text-blue-400"/> {req.details.cpu} Cores</span>
                                  <span className="flex items-center gap-1.5"><Database className="w-3.5 h-3.5 text-purple-400"/> {req.details.memory} Gi</span>
                                  <span className="flex items-center gap-1.5"><Layers className="w-3.5 h-3.5 text-emerald-400"/> {req.details.gpu} GPUs</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-sm text-neutral-400">{req.requestedBy}</td>
                              <td className="px-6 py-4">
                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                                  req.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                                  req.status === 'rejected' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                                  'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                }`}>
                                  {req.status === 'approved' && <CheckCircle className="w-3.5 h-3.5" />}
                                  {req.status === 'rejected' && <XCircle className="w-3.5 h-3.5" />}
                                  {req.status === 'pending' && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                                  <span className="capitalize">{req.status}</span>
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                {user?.role === 'admin' && req.status === 'pending' ? (
                                  <div className="flex justify-end gap-2">
                                    <button onClick={() => handleAdminAction(req.id, 'approve')} className="px-3 py-1.5 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20 rounded-md text-sm font-medium transition-colors">Approve</button>
                                    <button onClick={() => handleAdminAction(req.id, 'reject')} className="px-3 py-1.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 rounded-md text-sm font-medium transition-colors">Reject</button>
                                  </div>
                                ) : (
                                  <span className="text-sm text-neutral-600 italic">
                                    {req.status !== 'pending' ? 'Resolved' : 'Waiting for Admin'}
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Deploy Inference Service Modal */}
      <Modal isOpen={isDeployModalOpen} onClose={() => setIsDeployModalOpen(false)} title="Deploy Inference Service">
        <form id="deploy-form" onSubmit={handleDeploy} className="space-y-6">
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Service Name</label>
            <input type="text" required value={deploymentName} onChange={e => setDeploymentName(e.target.value)} placeholder="e.g., my-llama-endpoint" className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all text-white placeholder:text-neutral-600" />
          </div>
          
          <div className="grid grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Runtime</label>
              <select value={runtime} onChange={e => setRuntime(e.target.value)} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all text-white">
                <option value="Triton">Triton Inference</option>
                <option value="HuggingFace">HuggingFace TGI</option>
                <option value="XGBoost">XGBoost Server</option>
                <option value="vLLM">vLLM</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Storage Type</label>
              <select value={storageType} onChange={e => setStorageType(e.target.value)} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all text-white">
                <option value="S3">S3 Bucket</option>
                <option value="PVC">Persistent Volume (PVC)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Storage Path / URI</label>
            <input type="text" required value={storagePath} onChange={e => setStoragePath(e.target.value)} placeholder={storageType === 'S3' ? 's3://bucket/path/to/model' : 'pvc-name/path/to/model'} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono text-sm text-white placeholder:text-neutral-600" />
          </div>

          <div className="bg-neutral-900/50 p-5 rounded-xl border border-white/5 space-y-5">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-indigo-400" /> Security & Credentials</h3>
            <div>
              <label className="block text-[10px] font-semibold text-neutral-500 uppercase tracking-widest mb-2">Vault Folder Name (Optional)</label>
              <input type="text" value={vaultFolder} onChange={e => setVaultFolder(e.target.value)} placeholder="e.g., secret/data/aifarm/abc0/my-model" className="w-full px-3 py-2 bg-black/50 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-sm text-white placeholder:text-neutral-700" />
            </div>
            
            {storageType === 'S3' && (
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                <div>
                  <label className="block text-[10px] font-semibold text-neutral-500 uppercase tracking-widest mb-2">AWS Access Key ID</label>
                  <input type="text" required value={awsKeyId} onChange={e => setAwsKeyId(e.target.value)} placeholder="AKIA..." className="w-full px-3 py-2 bg-black/50 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-sm font-mono text-white placeholder:text-neutral-700" />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-neutral-500 uppercase tracking-widest mb-2">AWS Secret Key</label>
                  <input type="password" required value={awsSecretKey} onChange={e => setAwsSecretKey(e.target.value)} placeholder="••••••••" className="w-full px-3 py-2 bg-black/50 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-sm font-mono text-white placeholder:text-neutral-700" />
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Target Namespace</label>
              <select value={deployNamespace} onChange={e => setDeployNamespace(e.target.value)} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all text-white">
                {activeContext?.namespaces.map(ns => <option key={ns} value={ns}>{ns}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Replicas</label>
              <input type="number" min="1" max="10" required value={replicas} onChange={e => setReplicas(parseInt(e.target.value))} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all text-white" />
            </div>
          </div>
        </form>
        <div className="mt-8 flex gap-3">
          <button type="button" onClick={() => setIsDeployModalOpen(false)} className="flex-1 px-4 py-2.5 border border-white/10 text-neutral-300 rounded-xl font-medium hover:bg-white/5 transition-colors">Cancel</button>
          <button type="submit" form="deploy-form" className="flex-1 px-4 py-2.5 bg-white text-black rounded-xl font-medium hover:bg-neutral-200 transition-colors">Deploy Service</button>
        </div>
      </Modal>

      {/* New Request Modal */}
      <Modal isOpen={isRequestModalOpen} onClose={() => setIsRequestModalOpen(false)} title="New Quota Request">
        <form id="request-form" onSubmit={handleCreateRequest} className="space-y-6">
          <div>
            <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Target Environment</label>
            <select value={reqEnvTarget} onChange={e => setReqEnvTarget(e.target.value)} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white">
              <option value="dev">Development (dev)</option>
              <option value="qa">Quality Assurance (qa)</option>
              <option value="uat">User Acceptance Testing (uat)</option>
              <option value="ml-rnd">ML Research & Development (ml-rnd)</option>
            </select>
          </div>
          
          <div className="grid grid-cols-3 gap-5">
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">CPU Cores</label>
              <input type="number" min="1" max="128" required value={reqCpu} onChange={e => setReqCpu(parseInt(e.target.value))} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">Memory (Gi)</label>
              <input type="number" min="1" max="512" required value={reqMem} onChange={e => setReqMem(parseInt(e.target.value))} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-400 uppercase tracking-widest mb-2">GPUs</label>
              <input type="number" min="0" max="16" required value={reqGpu} onChange={e => setReqGpu(parseInt(e.target.value))} className="w-full px-4 py-2.5 bg-neutral-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-white" />
            </div>
          </div>
        </form>
        <div className="mt-8 flex gap-3">
          <button type="button" onClick={() => setIsRequestModalOpen(false)} className="flex-1 px-4 py-2.5 border border-white/10 text-neutral-300 rounded-xl font-medium hover:bg-white/5 transition-colors">Cancel</button>
          <button type="submit" form="request-form" className="flex-1 px-4 py-2.5 bg-indigo-500 text-white rounded-xl font-medium hover:bg-indigo-400 transition-colors">Submit Request</button>
        </div>
      </Modal>

      {/* Delete Workload Confirmation Modal */}
      <Modal isOpen={!!workloadToDelete} onClose={() => setWorkloadToDelete(null)} title="Confirm Deletion">
        <div className="space-y-6">
          <p className="text-neutral-300">
            Are you sure you want to delete the workload <strong className="text-white font-mono">{workloadToDelete?.name}</strong>?
          </p>
          
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-5 text-sm">
            <p className="font-semibold text-red-400 mb-3">The following associated resources will also be deleted:</p>
            <ul className="list-disc pl-5 space-y-1.5 text-red-300/80">
              {workloadToDelete?.configMaps.map(cm => <li key={cm.name}>ConfigMap: <span className="font-mono text-red-300">{cm.name}</span></li>)}
              {workloadToDelete?.secrets.map(sec => <li key={sec.name}>Secret: <span className="font-mono text-red-300">{sec.name}</span></li>)}
              {workloadToDelete?.routes.map(rt => <li key={rt}>Route: <span className="font-mono text-red-300">{rt}</span></li>)}
              {workloadToDelete?.configMaps.length === 0 && workloadToDelete?.secrets.length === 0 && workloadToDelete?.routes.length === 0 && (
                <li className="text-red-400/50 italic list-none -ml-5">No associated ConfigMaps, Secrets, or Routes.</li>
              )}
            </ul>
          </div>
        </div>
        <div className="mt-8 flex gap-3">
          <button onClick={() => setWorkloadToDelete(null)} className="flex-1 px-4 py-2.5 border border-white/10 text-neutral-300 rounded-xl font-medium hover:bg-white/5 transition-colors">Cancel</button>
          <button onClick={confirmDeleteWorkload} className="flex-1 px-4 py-2.5 bg-red-500 text-white font-medium hover:bg-red-600 rounded-xl transition-colors">Delete Everything</button>
        </div>
      </Modal>

      {/* Generic Logs Modal */}
      <Modal isOpen={!!activeLogs} onClose={() => setActiveLogs(null)} title={`Logs: ${activeLogs?.name}`} isWide>
        <div className="bg-black rounded-xl border border-white/10 overflow-hidden h-[60vh] flex flex-col">
          <div className="bg-white/5 px-4 py-2 border-b border-white/10 flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/80"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></div>
          </div>
          <pre className="flex-1 overflow-auto text-emerald-400/90 font-mono text-sm p-5 whitespace-pre-wrap">
            {activeLogs?.logs || "No logs available for this service."}
          </pre>
        </div>
      </Modal>

      {/* ConfigMap / Secret Viewer Modal */}
      {activeResourceView && (
        <ResourceViewerModal 
          view={activeResourceView} 
          onClose={() => setActiveResourceView(null)} 
          onExec={() => {
            setActiveResourceView(null);
            setActiveExec({ name: activeResourceView.workloadName });
          }}
        />
      )}

      {/* Gating & CI/CD Modal */}
      {activeGatingView && (
        <GatingViewerModal
          workload={activeGatingView}
          onClose={() => setActiveGatingView(null)}
        />
      )}

      {/* Exec Terminal Modal */}
      {activeExec && (
        <ExecTerminalModal 
          name={activeExec.name} 
          onClose={() => setActiveExec(null)} 
        />
      )}

      <ChatBox />

    </div>
  );
}

// --- UI Components ---

function StatCard({ icon, title, used, limit, unit, color }: { icon: React.ReactNode, title: string, used: number, limit: number, unit: string, color: 'blue'|'purple'|'emerald' }) {
  const colors = {
    blue: { bg: 'bg-blue-500/10', text: 'text-blue-400', bar: 'bg-blue-500' },
    purple: { bg: 'bg-purple-500/10', text: 'text-purple-400', bar: 'bg-purple-500' },
    emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', bar: 'bg-emerald-500' }
  };
  const c = colors[color];
  const percentage = Math.min(100, (used / (limit || 1)) * 100);

  return (
    <div className="bg-[#111111] rounded-2xl border border-white/5 p-6 relative overflow-hidden group hover:border-white/10 transition-colors">
      <div className="flex items-center gap-3 mb-4">
        <div className={`p-2.5 ${c.bg} ${c.text} rounded-xl`}>{icon}</div>
        <h3 className="text-sm font-medium text-neutral-400">{title}</h3>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-4xl font-semibold text-white tracking-tight">{used}</span>
        <span className="text-sm text-neutral-500">/ {limit} {unit}</span>
      </div>
      <div className="w-full bg-white/5 rounded-full h-1.5 mt-6 overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className={`${c.bar} h-full rounded-full`} 
        />
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const isRunning = status === 'Running';
  const isProv = status === 'Provisioning';
  return (
    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border ${
      isRunning ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
      isProv ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 
      'bg-red-500/10 text-red-400 border-red-500/20'
    }`}>
      {isProv && <RefreshCw className="w-3 h-3 animate-spin" />}
      {isRunning && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />}
      {status}
    </span>
  );
}

function ActionButton({ icon, onClick, disabled, title, color }: { icon: React.ReactNode, onClick: () => void, disabled?: boolean, title: string, color: 'blue'|'indigo'|'red' }) {
  const colors = {
    blue: 'hover:text-blue-400 hover:bg-blue-500/10',
    indigo: 'hover:text-indigo-400 hover:bg-indigo-500/10',
    red: 'hover:text-red-400 hover:bg-red-500/10'
  };
  return (
    <button 
      onClick={onClick} 
      disabled={disabled} 
      className={`p-2 text-neutral-500 rounded-lg transition-all disabled:opacity-50 ${colors[color]}`} 
      title={title}
    >
      {icon}
    </button>
  );
}

function Modal({ isOpen, onClose, title, children, isWide = false }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode, isWide?: boolean }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div key="modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60 backdrop-blur-md" 
            onClick={onClose} 
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className={`relative bg-[#111111] border border-white/10 rounded-2xl shadow-2xl w-full ${isWide ? 'max-w-4xl' : 'max-w-lg'} overflow-hidden flex flex-col max-h-[90vh]`}
          >
            <div className="px-6 py-5 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
              <h2 className="text-lg font-semibold text-white tracking-tight">{title}</h2>
              <button onClick={onClose} className="text-neutral-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 overflow-y-auto">
              {children}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// --- Subcomponents for Modals ---

function ResourceViewerModal({ view, onClose, onExec }: { view: { workloadName: string, type: 'ConfigMaps' | 'Secrets', items: ConfigMapOrSecret[] }, onClose: () => void, onExec?: () => void }) {
  const [revealedSecrets, setRevealedSecrets] = useState<Record<string, boolean>>({});
  const [copiedKeys, setCopiedKeys] = useState<Record<string, boolean>>({});

  const toggleReveal = (key: string) => {
    setRevealedSecrets(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const decodeBase64 = (str: string) => {
    try { return atob(str); } catch (e) { return str; }
  };

  const handleCopy = (key: string, value: string) => {
    navigator.clipboard.writeText(value);
    setCopiedKeys(prev => ({ ...prev, [key]: true }));
    setTimeout(() => setCopiedKeys(prev => ({ ...prev, [key]: false })), 2000);
  };

  return (
    <Modal isOpen={true} onClose={onClose} title={`${view.type} for ${view.workloadName}`} isWide>
      <div className="space-y-6">
        {onExec && (
          <div className="flex justify-end mb-4">
            <button 
              onClick={onExec}
              className="flex items-center gap-2 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 px-4 py-2 rounded-lg border border-indigo-500/20 transition-colors text-sm font-medium"
            >
              <TerminalSquare className="w-4 h-4" />
              Exec into Container
            </button>
          </div>
        )}

        {view.items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 bg-white/[0.02] border border-white/5 rounded-xl border-dashed">
            {view.type === 'ConfigMaps' ? <FileText className="w-8 h-8 text-neutral-600 mb-3" /> : <Lock className="w-8 h-8 text-neutral-600 mb-3" />}
            <p className="text-neutral-400 font-medium">No {view.type.toLowerCase()} attached to this workload.</p>
          </div>
        ) : (
          view.items.map((item, idx) => (
            <div key={idx} className="bg-[#111111] border border-white/10 rounded-xl overflow-hidden shadow-lg">
              <div className="px-5 py-3.5 bg-white/[0.03] border-b border-white/10 font-medium text-neutral-200 flex items-center gap-2.5">
                {view.type === 'ConfigMaps' ? <FileText className="w-4 h-4 text-blue-400" /> : <Lock className="w-4 h-4 text-emerald-400" />}
                {item.name}
              </div>
              <div className="p-0">
                {Object.entries(item.data).map(([key, value]) => {
                  const isSecret = view.type === 'Secrets';
                  const isRevealed = revealedSecrets[`${item.name}-${key}`];
                  const actualValue = isSecret ? decodeBase64(value) : value;
                  const displayValue = isSecret ? (isRevealed ? actualValue : '••••••••••••••••••••••••') : actualValue;
                  const isCopied = copiedKeys[`${item.name}-${key}`];

                  return (
                    <div key={key} className="border-b border-white/5 last:border-0">
                      <div className="px-5 py-3 bg-white/[0.01] flex justify-between items-center">
                        <span className="text-sm font-mono font-medium text-indigo-300">{key}</span>
                        <div className="flex items-center gap-2">
                          {isSecret && (
                            <button onClick={() => toggleReveal(`${item.name}-${key}`)} className="text-xs flex items-center gap-1.5 text-neutral-400 hover:text-white transition-colors bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-md font-medium">
                              {isRevealed ? <><EyeOff className="w-3.5 h-3.5"/> Hide</> : <><Eye className="w-3.5 h-3.5"/> Reveal</>}
                            </button>
                          )}
                          <button 
                            onClick={() => handleCopy(`${item.name}-${key}`, actualValue)}
                            disabled={isSecret && !isRevealed}
                            className={`text-xs flex items-center gap-1.5 transition-colors px-3 py-1.5 rounded-md font-medium ${
                              isCopied ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed'
                            }`}
                          >
                            {isCopied ? <><Check className="w-3.5 h-3.5"/> Copied</> : <><Copy className="w-3.5 h-3.5"/> Copy</>}
                          </button>
                        </div>
                      </div>
                      <div className="p-5 bg-black/60 overflow-x-auto relative group">
                        <pre className={`text-sm font-mono whitespace-pre-wrap leading-relaxed ${isSecret && !isRevealed ? 'text-neutral-600 select-none' : 'text-neutral-300'}`}>
                          {displayValue}
                        </pre>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </Modal>
  );
}

function ExecTerminalModal({ name, onClose }: { name: string, onClose: () => void }) {
  const [history, setHistory] = useState<{type: 'input'|'output', text: string}[]>([
    { type: 'output', text: `Connected to container ${name}...` },
    { type: 'output', text: `Type 'help' for a list of mock commands.` }
  ]);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && input.trim()) {
      const cmd = input.trim();
      const newHistory = [...history, { type: 'input' as const, text: `$ ${cmd}` }];
      
      let output = '';
      const parts = cmd.split(' ');
      const baseCmd = parts[0];

      if (baseCmd === 'ls') output = 'bin  boot  dev  etc  home  lib  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var';
      else if (baseCmd === 'pwd') output = '/usr/src/app';
      else if (baseCmd === 'whoami') output = 'root';
      else if (baseCmd === 'env') output = 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\nHOSTNAME=pod-12345\nNODE_ENV=production';
      else if (baseCmd === 'echo') output = parts.slice(1).join(' ');
      else if (baseCmd === 'clear') {
        setHistory([]);
        setInput('');
        return;
      }
      else if (baseCmd === 'help') output = 'Available mock commands: ls, pwd, whoami, env, echo, clear';
      else output = `bash: ${baseCmd}: command not found`;

      newHistory.push({ type: 'output' as const, text: output });
      setHistory(newHistory);
      setInput('');
    }
  };

  return (
    <Modal isOpen={true} onClose={onClose} title={`Terminal: root@${name}`} isWide>
      <div className="bg-black rounded-xl border border-white/10 overflow-hidden h-[60vh] flex flex-col">
        <div className="bg-white/5 px-4 py-2 border-b border-white/10 flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/80"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></div>
        </div>
        <div className="flex-1 p-5 overflow-y-auto font-mono text-sm flex flex-col gap-1.5" onClick={() => document.getElementById('terminal-input')?.focus()}>
          {history.map((line, i) => (
            <div key={i} className={line.type === 'input' ? 'text-emerald-400' : 'text-neutral-300 whitespace-pre-wrap'}>
              {line.text}
            </div>
          ))}
          <div className="flex items-center text-emerald-400 mt-2">
            <span className="mr-2">$</span>
            <input 
              id="terminal-input"
              type="text" 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleCommand}
              className="flex-1 bg-transparent outline-none border-none text-emerald-400"
              autoFocus
              autoComplete="off"
              spellCheck="false"
            />
          </div>
          <div ref={bottomRef} />
        </div>
      </div>
    </Modal>
  );
}

function GatingViewerModal({ workload, onClose }: { workload: Workload, onClose: () => void }) {
  const g = workload.gating;
  if (!g) return null;

  return (
    <Modal isOpen={true} onClose={onClose} title={`CI/CD & Security Gating: ${workload.name}`} isWide>
      <div className="space-y-6">
        
        {/* GitHub Info */}
        <div className="bg-[#111111] rounded-xl border border-white/10 p-5">
          <h3 className="text-sm font-medium text-white mb-4 flex items-center gap-2">
            <Shield className="w-4 h-4 text-indigo-400" /> Source & Deployment
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/5 rounded-lg p-4 border border-white/5">
              <div className="text-xs text-neutral-500 uppercase tracking-widest mb-1">GitHub Repository</div>
              <div className="font-mono text-sm text-neutral-300">{g.githubRepo}</div>
            </div>
            <div className="bg-white/5 rounded-lg p-4 border border-white/5">
              <div className="text-xs text-neutral-500 uppercase tracking-widest mb-1">Workflow Run</div>
              <a href={g.workflowRunUrl} target="_blank" rel="noreferrer" className="font-mono text-sm text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 transition-colors">
                View Action Log <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* Security Scans */}
        <div className="bg-[#111111] rounded-xl border border-white/10 p-5">
          <h3 className="text-sm font-medium text-white mb-4 flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" /> Security Scans
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {/* Aqua Scan */}
            <div className="bg-white/5 rounded-lg p-4 border border-white/5">
              <div className="flex justify-between items-start mb-3">
                <div className="text-sm font-medium text-neutral-300">Aqua Security</div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${g.aquaScan.status === 'Passed' ? 'bg-emerald-500/20 text-emerald-400' : g.aquaScan.status === 'Warning' ? 'bg-amber-500/20 text-amber-400' : 'bg-red-500/20 text-red-400'}`}>
                  {g.aquaScan.status}
                </span>
              </div>
              <div className="flex gap-4">
                <div>
                  <div className="text-2xl font-semibold text-white">{g.aquaScan.critical}</div>
                  <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Critical</div>
                </div>
                <div>
                  <div className="text-2xl font-semibold text-white">{g.aquaScan.high}</div>
                  <div className="text-[10px] text-neutral-500 uppercase tracking-widest">High</div>
                </div>
              </div>
            </div>

            {/* Snyk Scan */}
            <div className="bg-white/5 rounded-lg p-4 border border-white/5">
              <div className="flex justify-between items-start mb-3">
                <div className="text-sm font-medium text-neutral-300">Snyk Scan</div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${g.snykScan.status === 'Passed' ? 'bg-emerald-500/20 text-emerald-400' : g.snykScan.status === 'Warning' ? 'bg-amber-500/20 text-amber-400' : 'bg-red-500/20 text-red-400'}`}>
                  {g.snykScan.status}
                </span>
              </div>
              <div className="flex gap-4">
                <div>
                  <div className="text-2xl font-semibold text-white">{g.snykScan.critical}</div>
                  <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Critical</div>
                </div>
                <div>
                  <div className="text-2xl font-semibold text-white">{g.snykScan.high}</div>
                  <div className="text-[10px] text-neutral-500 uppercase tracking-widest">High</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Code Quality */}
        <div className="bg-[#111111] rounded-xl border border-white/10 p-5">
          <h3 className="text-sm font-medium text-white mb-4 flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" /> Code Quality
          </h3>
          <div className="bg-white/5 rounded-lg p-4 border border-white/5 flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-neutral-300 mb-1">SonarQube</div>
              <div className="text-xs text-neutral-500">Quality Gate: <span className={`font-semibold ${g.sonarQube.qualityGate === 'Passed' ? 'text-emerald-400' : g.sonarQube.qualityGate === 'Warning' ? 'text-amber-400' : 'text-red-400'}`}>{g.sonarQube.qualityGate}</span></div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-semibold text-white">{g.sonarQube.coverage}%</div>
              <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Coverage</div>
            </div>
          </div>
        </div>

      </div>
    </Modal>
  );
}

function ChatBox() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const chatRef = useRef<any>(null);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setLoading(true);

    try {
      if (!chatRef.current) {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });
        chatRef.current = ai.chats.create({
          model: "gemini-3-flash-preview",
          config: {
            systemInstruction: "You are a helpful AI assistant for AIFarm, a platform for managing AI workloads and inference services.",
          }
        });
      }
      const response = await chatRef.current.sendMessage({ message: userMessage });
      setMessages(prev => [...prev, { role: 'model', text: response.text || 'No response' }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'Error generating response.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 p-4 bg-indigo-500 hover:bg-indigo-400 text-white rounded-full shadow-2xl transition-all z-50 ${isOpen ? 'scale-0' : 'scale-100'}`}
      >
        <MessageSquare className="w-6 h-6" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 w-96 h-[500px] bg-[#111111] border border-white/10 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
          >
            <div className="p-4 border-b border-white/10 bg-white/[0.02] flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <h3 className="font-semibold text-white">AI Assistant</h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-neutral-400 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 && (
                <div className="text-center text-neutral-500 mt-10">
                  <Sparkles className="w-8 h-8 mx-auto mb-3 opacity-50" />
                  <p>Ask me anything about AIFarm!</p>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl ${msg.role === 'user' ? 'bg-indigo-500 text-white rounded-tr-sm' : 'bg-white/10 text-neutral-200 rounded-tl-sm'}`}>
                    <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="max-w-[80%] p-3 rounded-2xl bg-white/10 text-neutral-200 rounded-tl-sm flex items-center gap-2">
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSend} className="p-4 border-t border-white/10 bg-white/[0.02]">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-neutral-900 border border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500/50"
                />
                <button 
                  type="submit" 
                  disabled={loading || !input.trim()}
                  className="p-2 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl disabled:opacity-50 transition-colors"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
